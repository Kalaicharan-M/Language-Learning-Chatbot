from bot.core import LanguageLearningBot

if __name__ == "__main__":
    bot = LanguageLearningBot()
    bot.collect_user_info()
    bot.start_conversation()
    bot.generate_report()