import os
from typing import Dict, List
import logging
from langchain_community.llms import Ollama
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('language_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class LanguageLearningBot:
    """Local language learning chatbot using Ollama"""
    
    def __init__(self):
        """Initialize with local LLM"""
        try:
            self.llm = Ollama(model="llama3")
            self.user_data: Dict[str, str] = {}
            self.conversation_history: List[str] = []
            logger.info("Bot initialized with local LLM")
        except Exception as e:
            logger.error(f"Initialization failed: {str(e)}")
            print("ERROR: Make sure Ollama is running (download from ollama.ai)")
            exit(1)

    def _get_valid_input(self, prompt: str, validator=None, error_msg: str = "Invalid input"):
        """Universal input validator"""
        while True:
            try:
                user_input = input(prompt).strip()
                if not user_input:
                    raise ValueError("Input cannot be empty")
                if validator and not validator(user_input):
                    raise ValueError(error_msg)
                return user_input
            except ValueError as e:
                print(f"Error: {str(e)}")

    def collect_user_info(self):
        """Collect and validate user information"""
        print("\n🌍 Welcome to Language Learning Bot!")
        
        self.user_data['user_id'] = self._get_valid_input("Enter your name: ")
        
        self.user_data['target_lang'] = self._get_valid_input(
            "Language to learn (e.g., Spanish): ",
            lambda x: len(x) >= 2,
            "Minimum 2 characters required"
        )
        
        self.user_data['native_lang'] = self._get_valid_input(
            "Your native language (e.g., English): ",
            lambda x: len(x) >= 2,
            "Minimum 2 characters required"
        )
        
        valid_levels = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2']
        self.user_data['level'] = self._get_valid_input(
            f"Your {self.user_data['target_lang']} level (A1-C2): ",
            lambda x: x.upper() in valid_levels,
            f"Must be one of: {', '.join(valid_levels)}"
        ).upper()
        
        print("\nChoose scenario:")
        scenarios = ["Restaurant", "Airport", "Hotel", "Market"]
        for i, scene in enumerate(scenarios, 1):
            print(f"{i}. {scene}")
        
        while True:
            try:
                choice = self._get_valid_input("Enter number (1-4): ")
                choice_num = int(choice)
                if 1 <= choice_num <= len(scenarios):
                    self.user_data['scene'] = scenarios[choice_num-1]
                    break
                print(f"Please enter between 1-{len(scenarios)}")
            except ValueError:
                print("Numbers only please")

    def generate_scenario(self) -> str:
        """Generate learning scenario"""
        try:
            prompt = PromptTemplate.from_template(
                """Create a {target_lang} learning scenario for {level} level.
                Native language: {native_lang}. Scenario: {scene}.
                Start with an opening line in {target_lang}."""
            )
            chain = LLMChain(llm=self.llm, prompt=prompt)
            return chain.run(**self.user_data)
        except Exception as e:
            logger.error(f"Scenario error: {str(e)}")
            return f"Let's practice {self.user_data['target_lang']} in {self.user_data['scene']}!"

    def start_conversation(self):
        """Main conversation loop"""
        print(f"\n💬 Starting {self.user_data['scene']} scenario")
        print("Type 'quit' to exit\n")
        
        scenario = self.generate_scenario()
        print(f"\n{scenario}\n")
        
        conv_prompt = PromptTemplate.from_template(
            """You're a {target_lang} teacher in {scene}.
            Respond naturally in {target_lang} at {level} level.
            Keep responses brief.
            Conversation:
            {history}
            Student: {input}
            Teacher:"""
        )
        
        while True:
            try:
                user_input = input("You: ").strip()
                if user_input.lower() == 'quit':
                    break
                if not user_input:
                    continue
                
                response = LLMChain(llm=self.llm, prompt=conv_prompt).run(
                    input=user_input,
                    history="\n".join(self.conversation_history[-3:]),
                    **self.user_data
                )
                print(f"Bot: {response}")
                self.conversation_history.append(f"You: {user_input}")
                self.conversation_history.append(f"Bot: {response}")
                
            except KeyboardInterrupt:
                print("\nEnding conversation...")
                break
            except Exception as e:
                logger.error(f"Conversation error: {str(e)}")
                print("Let's try that again")

    def generate_report(self):
        """Generate learning progress report"""
        print("\n📊 Learning Report")
        print("="*40)
        print(f"Name: {self.user_data['user_id']}")
        print(f"Language: {self.user_data['target_lang']}")
        print(f"Level: {self.user_data['level']}")
        print(f"Scenario: {self.user_data['scene']}")
        
        if self.conversation_history:
            print("\nLast exchanges:")
            for i, msg in enumerate(self.conversation_history[-4:], 1):
                print(f"{i}. {msg}")
        else:
            print("\nNo conversation history yet")