import os
from typing import Optional

def ensure_directory_exists(path: str) -> str:
    """Ensure directory exists and return absolute path"""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return os.path.abspath(path)

def validate_language_code(language: str) -> bool:
    """Validate if language code is 2-3 letters"""
    return language.isalpha() and 2 <= len(language) <= 3

def clean_input(text: str) -> Optional[str]:
    """Clean and validate user input"""
    text = text.strip()
    return text if text else None