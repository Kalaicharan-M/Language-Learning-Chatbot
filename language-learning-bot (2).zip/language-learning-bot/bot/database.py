from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from .utils import ensure_directory_exists
import os

Base = declarative_base()

class Mistake(Base):
    __tablename__ = 'mistakes'
    id = Column(Integer, primary_key=True)
    user_id = Column(String(50), nullable=False)
    mistake = Column(String(500), nullable=False)
    correction = Column(String(500), nullable=False)
    explanation = Column(String(1000))
    timestamp = Column(DateTime, default=datetime.utcnow)
    language = Column(String(10), nullable=False)
    scenario = Column(String(50))

class DatabaseManager:
    def __init__(self, db_path: str = 'database/learning.db'):
        # Ensure directory exists and get absolute path
        abs_db_path = ensure_directory_exists(db_path)
        
        self.engine = create_engine(f'sqlite:///{abs_db_path}')
        self._create_tables()
        self.Session = sessionmaker(bind=self.engine)

    def _create_tables(self):
        """Create all tables if they don't exist"""
        Base.metadata.create_all(self.engine)

    def add_mistake(self, user_id: str, mistake: str, correction: str, 
                   explanation: str, language: str, scenario: str):
        """Add a new mistake to the database"""
        with self.Session() as session:
            new_mistake = Mistake(
                user_id=user_id,
                mistake=mistake,
                correction=correction,
                explanation=explanation,
                language=language,
                scenario=scenario
            )
            session.add(new_mistake)
            session.commit()

    def get_user_mistakes(self, user_id: str):
        """Retrieve all mistakes for a specific user"""
        with self.Session() as session:
            return session.query(Mistake)\
                .filter_by(user_id=user_id)\
                .order_by(Mistake.timestamp.desc())\
                .all()

    def get_mistakes_by_language(self, user_id: str, language: str):
        """Retrieve mistakes for a specific language"""
        with self.Session() as session:
            return session.query(Mistake)\
                .filter_by(user_id=user_id, language=language)\
                .order_by(Mistake.timestamp.desc())\
                .all()